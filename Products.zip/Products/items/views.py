from django.shortcuts import render
from .models import products
from .forms import productsForm
# Create your views here.


def show(r):
    data = products.objects.all()
    my_data = {'data': data}
    return render(r, 'tabs/product.html',context=my_data)