from django.db import models

# Create your models here.
class products(models.Model):
    PrdName = models.CharField(max_length=80)
    PrdNo = models.IntegerField(primary_key=True)
    PrdQnty = models.IntegerField()