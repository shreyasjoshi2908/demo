from django import forms
from .models import products

class productsForm(forms.ModelForm):
    class Meta:
        model = products
        fields = '__all__'